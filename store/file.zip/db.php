<?php
//new db
$con= new mysqli("localhost","root","","news");


?>